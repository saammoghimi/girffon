<?php
require_once __DIR__ . "/session.php";
require_once __DIR__ . "/../config/database.php";

function girffonAdminRedirectInvoice(string $type, string $message): void
{
    header("Location: /GirffoN/admin-invoices.php?" . $type . "=" . rawurlencode($message));
    exit;
}

function girffonAdminMapInvoiceStatus(string $value): string
{
    $normalized = strtolower(trim($value));

    return match ($normalized) {
        "paid" => "paid",
        "cancelled" => "cancelled",
        default => "pending",
    };
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    girffonAdminRedirectInvoice("error", "Invalid request method.");
}

$invoiceNumber = trim((string) ($_POST["invoiceNumber"] ?? ""));
$orderNumber = trim((string) ($_POST["orderNumber"] ?? ""));
$customerName = trim((string) ($_POST["customerName"] ?? ""));
$invoiceDate = trim((string) ($_POST["date"] ?? ""));
$invoiceTotal = (float) ($_POST["amount"] ?? 0);
$invoiceStatus = girffonAdminMapInvoiceStatus((string) ($_POST["paymentStatus"] ?? ""));
$createdAt = $invoiceDate !== "" ? ($invoiceDate . " " . date("H:i:s")) : date("Y-m-d H:i:s");

if ($invoiceNumber === "" || $orderNumber === "" || $customerName === "" || $invoiceTotal <= 0) {
    girffonAdminRedirectInvoice("error", "Please complete all invoice fields.");
}

try {
    $orderStatement = $pdo->prepare(
        "SELECT id
         FROM orders
         WHERE order_number = :order_number
         LIMIT 1"
    );
    $orderStatement->execute([
        ":order_number" => $orderNumber,
    ]);
    $orderId = $orderStatement->fetchColumn();

    if (!$orderId) {
        girffonAdminRedirectInvoice("error", "No matching order was found for this invoice.");
    }

    $invoiceStatement = $pdo->prepare(
        "INSERT INTO invoices (order_id, invoice_number, invoice_status, invoice_total, pdf_path, created_at)
         VALUES (:order_id, :invoice_number, :invoice_status, :invoice_total, :pdf_path, :created_at)"
    );
    $invoiceStatement->execute([
        ":order_id" => (int) $orderId,
        ":invoice_number" => $invoiceNumber,
        ":invoice_status" => $invoiceStatus,
        ":invoice_total" => $invoiceTotal,
        ":pdf_path" => null,
        ":created_at" => $createdAt,
    ]);

    girffonAdminRedirectInvoice("status", "Invoice saved successfully.");
} catch (PDOException $exception) {
    if ((int) $exception->getCode() === 23000) {
        girffonAdminRedirectInvoice("error", "That invoice number already exists.");
    }

    girffonAdminRedirectInvoice("error", "Unable to save the invoice right now.");
}
