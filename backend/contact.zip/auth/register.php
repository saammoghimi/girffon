<?php
require_once "../config/database.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $first_name = trim($_POST["first_name"] ?? "");
    $last_name  = trim($_POST["last_name"] ?? "");
    $email      = trim($_POST["email"] ?? "");
    $password   = $_POST["password"] ?? "";

    if (!$first_name || !$last_name || !$email || !$password) {
        exit("All fields required");
    }

    $check = $pdo->prepare("SELECT id FROM users WHERE email = ?");
    $check->execute([$email]);

    if ($check->fetch()) {
        exit("Email already exists");
    }

    $hash = password_hash($password, PASSWORD_DEFAULT);

    $stmt = $pdo->prepare("
        INSERT INTO users
        (first_name, last_name, email, password_hash)
        VALUES (?, ?, ?, ?)
    ");

    $stmt->execute([
        $first_name,
        $last_name,
        $email,
        $hash
    ]);

    echo "Register success";
}
?>