<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
require_once __DIR__ . "/../config/database.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $username = trim($_POST["username"] ?? "");
    $password = $_POST["password"] ?? "";

    $stmt = $pdo->prepare("
        SELECT id, username, password_hash, role
        FROM users
        WHERE username = ?
        LIMIT 1
    ");

    $stmt->execute([$username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        exit("User not found");
    }

    if (!password_verify($password, $user["password_hash"])) {
        exit("Wrong password");
    }

    $_SESSION["user_id"] = (int) $user["id"];
    $_SESSION["girffon_user_id"] = (int) $user["id"];
    $_SESSION["username"] = $user["username"];
    $_SESSION["role"] = $user["role"];

    $redirectPath = '/GirffoN/ProfilePage.php';
    if (!empty($_SESSION['post_login_redirect'])) {
        $candidateRedirect = (string) $_SESSION['post_login_redirect'];
        if (strncmp($candidateRedirect, '/GirffoN/', 9) === 0) {
            $redirectPath = $candidateRedirect;
        }
        unset($_SESSION['post_login_redirect']);
    }

    header("Location: " . $redirectPath);
    exit;
}
?>