<?php

require_once __DIR__ . '/../config/mail.php';

function girffonOrderEmailFormatCurrency(float $amount): string
{
    return 'EUR ' . number_format($amount, 2, '.', ',');
}

function girffonOrderEmailBuildAppUrl(array $mailConfig): string
{
    if (!empty($mailConfig['app_url'])) {
        return rtrim((string) $mailConfig['app_url'], '/');
    }

    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = (string) ($_SERVER['HTTP_HOST'] ?? 'localhost');
    $scriptPath = str_replace('\\', '/', (string) ($_SERVER['SCRIPT_NAME'] ?? '/GirffoN/backend/checkout/place-order.php'));
    $segments = explode('/', trim($scriptPath, '/'));
    $rootSegment = $segments[0] ?? 'GirffoN';

    return $scheme . '://' . $host . '/' . $rootSegment;
}

function girffonOrderEmailRenderItemsHtml(array $items): string
{
    $rows = array_map(static function (array $item): string {
        $details = array_filter([
            $item['sku'] ? 'SKU: ' . $item['sku'] : '',
            $item['size'] ? 'Size: ' . $item['size'] : '',
            $item['color'] ? 'Color: ' . $item['color'] : '',
        ]);

        return '<tr>'
            . '<td style="padding:12px;border-bottom:1px solid #e5ddd0;vertical-align:top;">' . htmlspecialchars((string) $item['product_name'], ENT_QUOTES, 'UTF-8') . '<br><span style="color:#7a6a58;font-size:12px;">' . htmlspecialchars(implode(' | ', $details), ENT_QUOTES, 'UTF-8') . '</span></td>'
            . '<td style="padding:12px;border-bottom:1px solid #e5ddd0;text-align:center;vertical-align:top;">' . (int) $item['quantity'] . '</td>'
            . '<td style="padding:12px;border-bottom:1px solid #e5ddd0;text-align:right;vertical-align:top;">' . htmlspecialchars(girffonOrderEmailFormatCurrency((float) $item['price']), ENT_QUOTES, 'UTF-8') . '</td>'
            . '<td style="padding:12px;border-bottom:1px solid #e5ddd0;text-align:right;vertical-align:top;">' . htmlspecialchars(girffonOrderEmailFormatCurrency((float) $item['line_total']), ENT_QUOTES, 'UTF-8') . '</td>'
            . '</tr>';
    }, $items);

    return implode('', $rows);
}

function girffonOrderEmailRenderItemsText(array $items): string
{
    $lines = array_map(static function (array $item): string {
        $details = array_filter([
            $item['sku'] ? 'SKU ' . $item['sku'] : '',
            $item['size'] ? 'Size ' . $item['size'] : '',
            $item['color'] ? 'Color ' . $item['color'] : '',
        ]);

        return '- ' . $item['product_name']
            . ' | Qty: ' . (int) $item['quantity']
            . ' | Price: ' . girffonOrderEmailFormatCurrency((float) $item['price'])
            . ' | Line Total: ' . girffonOrderEmailFormatCurrency((float) $item['line_total'])
            . ($details ? ' | ' . implode(' | ', $details) : '');
    }, $items);

    return implode("\n", $lines);
}

function girffonRenderOrderConfirmationEmail(array $mailData): array
{
    $customerName = (string) ($mailData['customer_name'] ?? 'GirffoN Customer');
    $orderNumber = (string) ($mailData['order_number'] ?? '');
    $invoiceNumber = (string) ($mailData['invoice_number'] ?? '');
    $trackingCode = (string) ($mailData['tracking_code'] ?? '');
    $items = array_values($mailData['items'] ?? []);
    $total = (float) ($mailData['total'] ?? 0);
    $trackOrderUrl = (string) ($mailData['track_order_url'] ?? '');
    $downloadInvoiceUrl = (string) ($mailData['download_invoice_url'] ?? '');

    $subject = 'GirffoN Order Confirmation - ' . $orderNumber;
    $itemsHtml = girffonOrderEmailRenderItemsHtml($items);
    $itemsText = girffonOrderEmailRenderItemsText($items);
    $totalFormatted = girffonOrderEmailFormatCurrency($total);

    $html = '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>'
        . htmlspecialchars($subject, ENT_QUOTES, 'UTF-8')
        . '</title></head><body style="margin:0;padding:0;background:#f5f1ea;font-family:Georgia, Times New Roman, serif;color:#1f1812;">'
        . '<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background:#f5f1ea;padding:24px 0;">'
        . '<tr><td align="center">'
        . '<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="max-width:760px;background:#fffdf9;border:1px solid #e5ddd0;">'
        . '<tr><td style="padding:32px 36px;background:#1f1812;color:#f4ebdf;"><div style="font-size:13px;letter-spacing:2px;text-transform:uppercase;">GirffoN</div><h1 style="margin:10px 0 0;font-size:28px;font-weight:600;">Order Confirmed</h1></td></tr>'
        . '<tr><td style="padding:32px 36px;">'
        . '<p style="margin:0 0 16px;font-size:16px;line-height:1.7;">Dear ' . htmlspecialchars($customerName, ENT_QUOTES, 'UTF-8') . ', your order has been placed successfully. We have saved your order details and prepared your invoice for download.</p>'
        . '<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin:0 0 24px;border-collapse:collapse;">'
        . '<tr><td style="padding:10px 0;border-bottom:1px solid #e5ddd0;color:#7a6a58;width:32%;">Order Number</td><td style="padding:10px 0;border-bottom:1px solid #e5ddd0;font-weight:600;">' . htmlspecialchars($orderNumber, ENT_QUOTES, 'UTF-8') . '</td></tr>'
        . '<tr><td style="padding:10px 0;border-bottom:1px solid #e5ddd0;color:#7a6a58;">Invoice Number</td><td style="padding:10px 0;border-bottom:1px solid #e5ddd0;font-weight:600;">' . htmlspecialchars($invoiceNumber, ENT_QUOTES, 'UTF-8') . '</td></tr>'
        . '<tr><td style="padding:10px 0;border-bottom:1px solid #e5ddd0;color:#7a6a58;">Tracking Code</td><td style="padding:10px 0;border-bottom:1px solid #e5ddd0;font-weight:600;">' . htmlspecialchars($trackingCode, ENT_QUOTES, 'UTF-8') . '</td></tr>'
        . '<tr><td style="padding:10px 0;border-bottom:1px solid #e5ddd0;color:#7a6a58;">Total Price</td><td style="padding:10px 0;border-bottom:1px solid #e5ddd0;font-weight:600;">' . htmlspecialchars($totalFormatted, ENT_QUOTES, 'UTF-8') . '</td></tr>'
        . '</table>'
        . '<h2 style="margin:0 0 12px;font-size:18px;">Items</h2>'
        . '<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="border-collapse:collapse;margin:0 0 24px;">'
        . '<thead><tr><th align="left" style="padding:12px;border-bottom:1px solid #cdb79e;color:#7a6a58;font-size:12px;text-transform:uppercase;letter-spacing:1px;">Product</th><th align="center" style="padding:12px;border-bottom:1px solid #cdb79e;color:#7a6a58;font-size:12px;text-transform:uppercase;letter-spacing:1px;">Qty</th><th align="right" style="padding:12px;border-bottom:1px solid #cdb79e;color:#7a6a58;font-size:12px;text-transform:uppercase;letter-spacing:1px;">Price</th><th align="right" style="padding:12px;border-bottom:1px solid #cdb79e;color:#7a6a58;font-size:12px;text-transform:uppercase;letter-spacing:1px;">Total</th></tr></thead>'
        . '<tbody>' . $itemsHtml . '</tbody></table>'
        . '<table role="presentation" cellspacing="0" cellpadding="0" style="margin:0 0 18px;"><tr>'
        . '<td style="padding-right:12px;"><a href="' . htmlspecialchars($trackOrderUrl, ENT_QUOTES, 'UTF-8') . '" style="display:inline-block;padding:14px 22px;background:#1f1812;color:#f4ebdf;text-decoration:none;font-weight:600;">Track Order</a></td>'
        . '<td><a href="' . htmlspecialchars($downloadInvoiceUrl, ENT_QUOTES, 'UTF-8') . '" style="display:inline-block;padding:14px 22px;background:#c9a56a;color:#1f1812;text-decoration:none;font-weight:600;">Download Invoice</a></td>'
        . '</tr></table>'
        . '<p style="margin:0;color:#7a6a58;font-size:13px;line-height:1.7;">If the buttons above do not open directly, copy these links into your browser:</p>'
        . '<p style="margin:8px 0 0;font-size:13px;line-height:1.7;"><a href="' . htmlspecialchars($trackOrderUrl, ENT_QUOTES, 'UTF-8') . '">' . htmlspecialchars($trackOrderUrl, ENT_QUOTES, 'UTF-8') . '</a><br><a href="' . htmlspecialchars($downloadInvoiceUrl, ENT_QUOTES, 'UTF-8') . '">' . htmlspecialchars($downloadInvoiceUrl, ENT_QUOTES, 'UTF-8') . '</a></p>'
        . '</td></tr></table></td></tr></table></body></html>';

    $text = "GirffoN Order Confirmation\n"
        . "Customer: {$customerName}\n"
        . "Order Number: {$orderNumber}\n"
        . "Invoice Number: {$invoiceNumber}\n"
        . "Tracking Code: {$trackingCode}\n"
        . "Total Price: {$totalFormatted}\n\n"
        . "Items:\n{$itemsText}\n\n"
        . "Track Order: {$trackOrderUrl}\n"
        . "Download Invoice: {$downloadInvoiceUrl}\n";

    return [
        'subject' => $subject,
        'html' => $html,
        'text' => $text,
    ];
}

function girffonSendMailWithPhpMailer(array $mailConfig, array $message): bool
{
    $autoloadPath = dirname(__DIR__, 2) . '/vendor/autoload.php';
    if (is_file($autoloadPath)) {
        require_once $autoloadPath;
    }

    if (!class_exists('PHPMailer\\PHPMailer\\PHPMailer')) {
        throw new RuntimeException('SMTP transport requires PHPMailer to be installed.');
    }

    $mailer = new PHPMailer\PHPMailer\PHPMailer(true);
    $mailer->isSMTP();
    $mailer->Host = (string) ($mailConfig['smtp']['host'] ?? '');
    $mailer->Port = (int) ($mailConfig['smtp']['port'] ?? 587);
    $mailer->SMTPAuth = (bool) ($mailConfig['smtp']['auth'] ?? true);
    $mailer->Username = (string) ($mailConfig['smtp']['username'] ?? '');
    $mailer->Password = (string) ($mailConfig['smtp']['password'] ?? '');

    $encryption = (string) ($mailConfig['smtp']['encryption'] ?? 'tls');
    if ($encryption !== '') {
        $mailer->SMTPSecure = $encryption;
    }

    $mailer->setFrom((string) $mailConfig['from_email'], (string) $mailConfig['from_name']);
    $mailer->addReplyTo((string) $mailConfig['reply_to_email'], (string) $mailConfig['reply_to_name']);
    $mailer->addAddress((string) $message['to_email'], (string) $message['to_name']);
    $mailer->Subject = (string) $message['subject'];
    $mailer->isHTML(true);
    $mailer->Body = (string) $message['html'];
    $mailer->AltBody = (string) $message['text'];

    return $mailer->send();
}

function girffonSendMailWithPhpMail(array $mailConfig, array $message): bool
{
    $headers = [
        'MIME-Version: 1.0',
        'Content-Type: text/html; charset=UTF-8',
        'From: ' . $mailConfig['from_name'] . ' <' . $mailConfig['from_email'] . '>',
        'Reply-To: ' . $mailConfig['reply_to_name'] . ' <' . $mailConfig['reply_to_email'] . '>',
    ];

    $warningMessage = '';
    set_error_handler(static function (int $severity, string $errorMessage) use (&$warningMessage): bool {
        $warningMessage = $errorMessage;
        return true;
    });

    try {
        $result = mail((string) $message['to_email'], (string) $message['subject'], (string) $message['html'], implode("\r\n", $headers));
    } finally {
        restore_error_handler();
    }

    if ($warningMessage !== '') {
        throw new RuntimeException($warningMessage);
    }

    return $result;
}

function girffonSendOrderConfirmationEmail(array $mailData): bool
{
    $mailConfig = girffonMailConfig();
    $appUrl = girffonOrderEmailBuildAppUrl($mailConfig);
    $rendered = girffonRenderOrderConfirmationEmail([
        'customer_name' => $mailData['customer_name'] ?? 'GirffoN Customer',
        'order_number' => $mailData['order_number'] ?? '',
        'invoice_number' => $mailData['invoice_number'] ?? '',
        'tracking_code' => $mailData['tracking_code'] ?? '',
        'items' => $mailData['items'] ?? [],
        'total' => $mailData['total'] ?? 0,
        'track_order_url' => $appUrl . '/TrackOrder.php?order_number=' . rawurlencode((string) ($mailData['order_number'] ?? '')),
        'download_invoice_url' => $appUrl . '/backend/admin/invoice-pdf.php?id=' . rawurlencode((string) ($mailData['invoice_id'] ?? '')),
    ]);

    $message = [
        'to_email' => (string) ($mailData['customer_email'] ?? ''),
        'to_name' => (string) ($mailData['customer_name'] ?? 'GirffoN Customer'),
        'subject' => $rendered['subject'],
        'html' => $rendered['html'],
        'text' => $rendered['text'],
    ];

    if (($mailConfig['transport'] ?? 'mail') === 'smtp') {
        return girffonSendMailWithPhpMailer($mailConfig, $message);
    }

    return girffonSendMailWithPhpMail($mailConfig, $message);
}