<?php

function girffonMailConfig(): array
{
    static $config = null;
    if ($config !== null) {
        return $config;
    }

    $transport = strtolower(trim((string) (getenv('GIRFFON_MAIL_TRANSPORT') ?: 'mail')));
    if ($transport === '') {
        $transport = 'mail';
    }

    $config = [
        'transport' => $transport,
        'from_email' => (string) (getenv('GIRFFON_MAIL_FROM_EMAIL') ?: 'no-reply@girffon.local'),
        'from_name' => (string) (getenv('GIRFFON_MAIL_FROM_NAME') ?: 'GirffoN'),
        'reply_to_email' => (string) (getenv('GIRFFON_MAIL_REPLY_TO_EMAIL') ?: 'support@girffon.local'),
        'reply_to_name' => (string) (getenv('GIRFFON_MAIL_REPLY_TO_NAME') ?: 'GirffoN Support'),
        'app_url' => rtrim((string) (getenv('GIRFFON_APP_URL') ?: ''), '/'),
        'smtp' => [
            'host' => (string) (getenv('GIRFFON_SMTP_HOST') ?: ''),
            'port' => (int) (getenv('GIRFFON_SMTP_PORT') ?: 587),
            'username' => (string) (getenv('GIRFFON_SMTP_USERNAME') ?: ''),
            'password' => (string) (getenv('GIRFFON_SMTP_PASSWORD') ?: ''),
            'encryption' => (string) (getenv('GIRFFON_SMTP_ENCRYPTION') ?: 'tls'),
            'auth' => filter_var((string) (getenv('GIRFFON_SMTP_AUTH') ?: 'true'), FILTER_VALIDATE_BOOLEAN),
        ],
    ];

    return $config;
}