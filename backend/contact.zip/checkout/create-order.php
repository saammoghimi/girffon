<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../cart/cart-common.php';

function girffonCheckoutJson(int $statusCode, array $payload): void
{
    http_response_code($statusCode);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function girffonCheckoutRequestData(): array
{
    $raw = file_get_contents('php://input');
    if (!is_string($raw) || trim($raw) === '') {
        return [];
    }

    $decoded = json_decode($raw, true);
    return is_array($decoded) ? $decoded : [];
}

function girffonCheckoutColumnExists(PDO $pdo, string $table, string $column): bool
{
    $statement = $pdo->prepare("SHOW COLUMNS FROM {$table} LIKE :column");
    $statement->execute([':column' => $column]);
    return (bool) $statement->fetch(PDO::FETCH_ASSOC);
}

function girffonCheckoutEnsureSchema(PDO $pdo): void
{
    static $checked = false;
    if ($checked) {
        return;
    }

    $orderColumns = [
        'user_id' => 'ALTER TABLE orders ADD user_id INT NULL AFTER id',
        'phone' => 'ALTER TABLE orders ADD phone VARCHAR(50) NULL AFTER customer_email',
        'address' => 'ALTER TABLE orders ADD address VARCHAR(255) NULL AFTER phone',
        'city' => 'ALTER TABLE orders ADD city VARCHAR(120) NULL AFTER address',
        'country' => 'ALTER TABLE orders ADD country VARCHAR(120) NULL AFTER city',
        'postcode' => 'ALTER TABLE orders ADD postcode VARCHAR(40) NULL AFTER country',
        'subtotal' => 'ALTER TABLE orders ADD subtotal DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER postcode',
        'shipping' => 'ALTER TABLE orders ADD shipping DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER subtotal',
        'payment_method' => 'ALTER TABLE orders ADD payment_method VARCHAR(50) NOT NULL DEFAULT "bank_transfer" AFTER total',
    ];

    foreach ($orderColumns as $column => $sql) {
        if (!girffonCheckoutColumnExists($pdo, 'orders', $column)) {
            $pdo->exec($sql);
        }
    }

    $orderItemColumns = [
        'product_id' => 'ALTER TABLE order_items ADD product_id VARCHAR(100) NULL AFTER order_id',
        'name' => 'ALTER TABLE order_items ADD name VARCHAR(200) NULL AFTER product_id',
        'line_total' => 'ALTER TABLE order_items ADD line_total DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER price',
    ];

    foreach ($orderItemColumns as $column => $sql) {
        if (!girffonCheckoutColumnExists($pdo, 'order_items', $column)) {
            $pdo->exec($sql);
        }
    }

    $invoiceColumns = [
        'user_id' => 'ALTER TABLE invoices ADD user_id INT NULL AFTER order_id',
        'subtotal' => 'ALTER TABLE invoices ADD subtotal DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER user_id',
        'tax' => 'ALTER TABLE invoices ADD tax DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER subtotal',
        'shipping' => 'ALTER TABLE invoices ADD shipping DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER tax',
        'total' => 'ALTER TABLE invoices ADD total DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER shipping',
        'status' => 'ALTER TABLE invoices ADD status VARCHAR(50) NOT NULL DEFAULT "pending" AFTER total',
    ];

    foreach ($invoiceColumns as $column => $sql) {
        if (!girffonCheckoutColumnExists($pdo, 'invoices', $column)) {
            $pdo->exec($sql);
        }
    }

    $checked = true;
}

function girffonNextSequenceNumber(PDO $pdo, string $table, string $column, string $prefix, int $year): string
{
    $pattern = $prefix . '-' . $year . '-%';
    $statement = $pdo->prepare("SELECT {$column} FROM {$table} WHERE {$column} LIKE :pattern ORDER BY id DESC LIMIT 1 FOR UPDATE");
    $statement->execute([':pattern' => $pattern]);
    $lastValue = (string) ($statement->fetchColumn() ?: '');
    $lastNumber = 0;

    if ($lastValue !== '' && preg_match('/-(\d{4})$/', $lastValue, $matches)) {
        $lastNumber = (int) $matches[1];
    }

    return sprintf('%s-%d-%04d', $prefix, $year, $lastNumber + 1);
}

function girffonNormalizeSessionCartItem(array $item): array
{
    $quantity = max(1, (int) ($item['quantity'] ?? $item['qty'] ?? 1));
    $price = round((float) ($item['priceNumber'] ?? $item['price'] ?? 0), 2);
    $lineTotal = round((float) ($item['line_total'] ?? $item['total_price'] ?? ($price * $quantity)), 2);
    $sku = trim((string) ($item['sku'] ?? $item['id'] ?? $item['code'] ?? ''));
    $name = trim((string) ($item['name'] ?? $item['title'] ?? 'GirffoN Product'));

    return [
        'product_id' => $sku,
        'sku' => $sku,
        'name' => $name !== '' ? $name : 'GirffoN Product',
        'size' => trim((string) ($item['size'] ?? '')),
        'color' => trim((string) ($item['color'] ?? '')),
        'quantity' => $quantity,
        'price' => $price,
        'line_total' => $lineTotal,
        'image' => trim((string) ($item['image'] ?? $item['img'] ?? '')),
    ];
}

function girffonCheckoutUser(PDO $pdo, int $userId): ?array
{
    if ($userId <= 0) {
        return null;
    }

    $statement = $pdo->prepare('SELECT id, username, first_name, last_name, email, phone, address, city, country FROM users WHERE id = :id LIMIT 1');
    $statement->execute([':id' => $userId]);
    $user = $statement->fetch(PDO::FETCH_ASSOC);

    return is_array($user) ? $user : null;
}

function girffonCheckoutField(array $shipping, ?array $user, string $shippingKey, string $userKey = ''): string
{
    $value = trim((string) ($shipping[$shippingKey] ?? ''));
    if ($value !== '') {
        return $value;
    }

    if ($user && $userKey !== '') {
        return trim((string) ($user[$userKey] ?? ''));
    }

    return '';
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    girffonCheckoutJson(405, ['ok' => false, 'message' => 'Method not allowed.']);
}

$payload = girffonCheckoutRequestData();
$shipping = is_array($payload['shipping'] ?? null) ? $payload['shipping'] : [];
$userId = (int) ($_SESSION['user_id'] ?? $_SESSION['girffon_user_id'] ?? 0);
$user = girffonCheckoutUser($pdo, $userId);

$sessionItems = girffonCartSessionItems();
$normalizedItems = array_values(array_filter(array_map('girffonNormalizeSessionCartItem', $sessionItems), static function (array $item): bool {
    return $item['name'] !== '' && $item['quantity'] > 0 && $item['price'] >= 0;
}));

if (!$normalizedItems) {
    girffonCheckoutJson(422, ['ok' => false, 'message' => 'Your cart is empty.']);
}

$customerName = girffonCheckoutField($shipping, $user, 'fullName');
if ($customerName === '' && $user) {
    $customerName = trim(((string) ($user['first_name'] ?? '')) . ' ' . ((string) ($user['last_name'] ?? '')));
}
if ($customerName === '' && $user) {
    $customerName = trim((string) ($user['username'] ?? ''));
}

$customerEmail = strtolower(girffonCheckoutField($shipping, $user, 'email', 'email'));
$customerPhone = girffonCheckoutField($shipping, $user, 'phone', 'phone');
$customerAddress = girffonCheckoutField($shipping, $user, 'address', 'address');
$customerCity = girffonCheckoutField($shipping, $user, 'city', 'city');
$customerCountry = girffonCheckoutField($shipping, $user, 'country', 'country');
$customerPostcode = trim((string) ($shipping['postalCode'] ?? ''));

if ($customerName === '') {
    girffonCheckoutJson(422, ['ok' => false, 'message' => 'Customer name is required.']);
}

if ($customerEmail === '' || !filter_var($customerEmail, FILTER_VALIDATE_EMAIL)) {
    girffonCheckoutJson(422, ['ok' => false, 'message' => 'A valid email is required.']);
}

if ($customerPhone === '' || $customerAddress === '' || $customerCity === '' || $customerCountry === '') {
    girffonCheckoutJson(422, ['ok' => false, 'message' => 'Phone, address, city, and country are required.']);
}

$subtotal = round(array_reduce($normalizedItems, static function (float $sum, array $item): float {
    return $sum + $item['line_total'];
}, 0.0), 2);
$shippingAmount = 0.0;
$taxAmount = 0.0;
$total = round($subtotal + $shippingAmount + $taxAmount, 2);

if ($total <= 0) {
    girffonCheckoutJson(422, ['ok' => false, 'message' => 'Order total must be greater than zero.']);
}

$year = (int) date('Y');
$trackingCode = sprintf('TRK-%d-%06d', $year, random_int(1, 999999));
$paymentMethod = trim((string) ($payload['payment_method'] ?? 'bank_transfer')) ?: 'bank_transfer';
$paymentStatus = 'pending';
$orderStatus = 'processing';
$invoiceStatus = 'pending';

try {
    girffonCheckoutEnsureSchema($pdo);
    $pdo->beginTransaction();

    $orderNumber = girffonNextSequenceNumber($pdo, 'orders', 'order_number', 'GF', $year);
    $insertOrder = $pdo->prepare(
        'INSERT INTO orders (user_id, order_number, customer_name, customer_email, phone, address, city, country, postcode, subtotal, shipping, total, payment_method, payment_status, order_status, tracking_code)
         VALUES (:user_id, :order_number, :customer_name, :customer_email, :phone, :address, :city, :country, :postcode, :subtotal, :shipping, :total, :payment_method, :payment_status, :order_status, :tracking_code)'
    );
    $insertOrder->execute([
        ':user_id' => $user ? (int) $user['id'] : null,
        ':order_number' => $orderNumber,
        ':customer_name' => $customerName,
        ':customer_email' => $customerEmail,
        ':phone' => $customerPhone,
        ':address' => $customerAddress,
        ':city' => $customerCity,
        ':country' => $customerCountry,
        ':postcode' => $customerPostcode !== '' ? $customerPostcode : null,
        ':subtotal' => $subtotal,
        ':shipping' => $shippingAmount,
        ':total' => $total,
        ':payment_method' => $paymentMethod,
        ':payment_status' => $paymentStatus,
        ':order_status' => $orderStatus,
        ':tracking_code' => $trackingCode,
    ]);

    $orderId = (int) $pdo->lastInsertId();

    $insertItem = $pdo->prepare(
        'INSERT INTO order_items (order_id, product_id, name, product_name, sku, size, color, quantity, price, line_total, image)
         VALUES (:order_id, :product_id, :name, :product_name, :sku, :size, :color, :quantity, :price, :line_total, :image)'
    );

    foreach ($normalizedItems as $item) {
        $insertItem->execute([
            ':order_id' => $orderId,
            ':product_id' => $item['product_id'] !== '' ? $item['product_id'] : null,
            ':name' => $item['name'],
            ':product_name' => $item['name'],
            ':sku' => $item['sku'] !== '' ? $item['sku'] : null,
            ':size' => $item['size'] !== '' ? $item['size'] : null,
            ':color' => $item['color'] !== '' ? $item['color'] : null,
            ':quantity' => $item['quantity'],
            ':price' => $item['price'],
            ':line_total' => $item['line_total'],
            ':image' => $item['image'] !== '' ? $item['image'] : null,
        ]);
    }

    $invoiceNumber = girffonNextSequenceNumber($pdo, 'invoices', 'invoice_number', 'INV', $year);
    $insertInvoice = $pdo->prepare(
        'INSERT INTO invoices (order_id, user_id, invoice_number, subtotal, tax, shipping, total, status, invoice_status, invoice_total)
         VALUES (:order_id, :user_id, :invoice_number, :subtotal, :tax, :shipping, :total, :status, :invoice_status, :invoice_total)'
    );
    $insertInvoice->execute([
        ':order_id' => $orderId,
        ':user_id' => $user ? (int) $user['id'] : null,
        ':invoice_number' => $invoiceNumber,
        ':subtotal' => $subtotal,
        ':tax' => $taxAmount,
        ':shipping' => $shippingAmount,
        ':total' => $total,
        ':status' => $invoiceStatus,
        ':invoice_status' => $invoiceStatus,
        ':invoice_total' => $total,
    ]);

    $invoiceId = (int) $pdo->lastInsertId();
    girffonCartSaveSessionItems([]);
    $pdo->commit();

    girffonCheckoutJson(200, [
        'ok' => true,
        'message' => 'Order placed successfully.',
        'redirectUrl' => '/GirffoN/CartTest.html?checkout=success',
        'order' => [
            'id' => $orderId,
            'order_number' => $orderNumber,
            'user_id' => $user ? (int) $user['id'] : null,
            'customer_name' => $customerName,
            'email' => $customerEmail,
            'phone' => $customerPhone,
            'address' => $customerAddress,
            'city' => $customerCity,
            'country' => $customerCountry,
            'postcode' => $customerPostcode,
            'subtotal' => $subtotal,
            'shipping' => $shippingAmount,
            'total' => $total,
            'payment_method' => $paymentMethod,
            'payment_status' => $paymentStatus,
            'order_status' => $orderStatus,
            'created_at' => date('Y-m-d H:i:s'),
            'tracking_code' => $trackingCode,
        ],
        'invoice' => [
            'id' => $invoiceId,
            'invoice_number' => $invoiceNumber,
            'order_id' => $orderId,
            'user_id' => $user ? (int) $user['id'] : null,
            'subtotal' => $subtotal,
            'tax' => $taxAmount,
            'shipping' => $shippingAmount,
            'total' => $total,
            'status' => $invoiceStatus,
            'created_at' => date('Y-m-d H:i:s'),
        ],
    ]);
} catch (Throwable $throwable) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    girffonCheckoutJson(500, [
        'ok' => false,
        'message' => 'Unable to create the order right now.',
    ]);
}